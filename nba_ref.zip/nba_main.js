function news_Toggle(){
    var news = document.getElementById("news");
    var home = document.getElementById("home");
    if(news.style.display =='none'){
      home.style.display = 'none';
      news.style.display = 'block';
    }
    else{
      news.style.display = 'none';
    }
  }
  function home_Toggle(){
    var news = document.getElementById("news");
    var home = document.getElementById("home");
    if(home.style.display =='none'){
      news.style.display = 'none';
      home.style.display = 'block';
    }
    else{
      home.style.display = 'none';
    }
  }