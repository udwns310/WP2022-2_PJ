


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="nba.css"/>
  <script type="text/javascript" src="nba_main.js"></script>
</head>
<body>

  <h1>NBA Reference</h1>

  <ul>
  <li><a href="javascript:home_Toggle();">Home</a></li>
  <li><a href="javascript:news_Toggle();">News</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2018-19</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="home.php">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals)(예정)</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2019-20</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="#">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals)(예정)</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2020-21</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="#">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals(예정))</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2021-22</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="#">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals)(예정)</a>
    </div>
  </li>
</ul>

<?php

	$connect = mysqli_connect ('localhost', 'root', '1234');   
	mysqli_select_db ($connect, 'nba_18_19');          // 질의 수행

	/* ---------- 한글 깨짐 방지 코드 -----------------*/ 
	
	mysqli_query($connect, "set session character_set_connection=utf8;");		 
	mysqli_query($connect, "set session character_set_results=utf8;");		 
	mysqli_query($connect, "set session character_set_client=utf8;");	

	$sql = "select *from apr";                      // 테이블 검색 질의
	$result = mysqli_query ($connect, $sql);          // 질의 수행
	$count = mysqli_num_fields ($result);             // 필드의 개수 구하기
?>

<table class="rst18-19" style=display:none border='2' bordercolor='blue' cellpadding='10'>
	<tr>
		<td bgcolor='#FFFF00' align='center'><B> 날짜 </B></td> 
		<td bgcolor='#FFFF00' align='center'><B> 시간 </B></td> 
		<td bgcolor='#FFFF00' align='center'><B> 홈팀 </B></td> 
		<td bgcolor='#FFFF00' align='center'><B> 원정팀 </B></td> 
		<td bgcolor='#FFFF00' align='center'><B> 구장 </B></td> 
		<td bgcolor='#FFFF00' align='center'><B> 점수 </B></td>
	</tr>	

<?php

	while ($rows=mysqli_fetch_row($result))     // 레코드의 개수만큼 반복
	{
		echo "<tr>";
		for ($a = 0; $a < $count; $a++)          // 필드의 수만큼 반복
		{
			echo "<td> $rows[$a] </td>";
		}
		echo "</tr>";
	}

	?>

</table><br>



<div id=home><div class=flex-container>Welcome! Here is NBA Reference!</div></div>



<?php //네이버 뉴스 API로 가져오기
  $client_id = "xRHUYe4fZm2h3lKr9pvA";
  $client_secret = "1y7v_cZSV6";
  $encText = urlencode("NBA");
  $url = "https://openapi.naver.com/v1/search/news?query=".$encText."&sort=sim"; // json 결과
//  $url = "https://openapi.naver.com/v1/search/blog.xml?query=".$encText; // xml 결과
  $is_post = false;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_POST, $is_post);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $headers = array();
  $headers[] = "X-Naver-Client-Id: ".$client_id;
  $headers[] = "X-Naver-Client-Secret: ".$client_secret;
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  $response = curl_exec ($ch);
  $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  //echo "status_code:".$status_code."";
  curl_close ($ch);
  echo "<table id=news style=display:none>";
  if($status_code == 200) {
    $result = json_decode($response, true);
    //print_r($result);
    $count=0;
    $total = $result['total'];
    //echo $total;
    while($count<10){
      $temp = "<tr><td>";
      $temp = $temp.$count+1;
      $temp = $temp."</td><td>";
      $temp = $temp.$result['items'][$count]['title'];
      $temp = $temp."</td><td>";
      $temp = $temp.$result['items'][$count]['link'];
      $temp = $temp."</td><td>";
      $temp = $temp.$result['items'][$count]['description'];
      $temp = $temp."</td></tr>";
      echo $temp;
      $count++;
    }}
    echo "</table>";?>






</body>
</html>