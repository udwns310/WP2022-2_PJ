<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="nba.css"/>
  <script type="text/javascript" src="nba_main.js"></script>
</head>
<body>

<style>
table, tr, td{
    border-collapse: collapse;
    border: 1px solid black;
  }
  table{
    margin: 20px;
  }
  
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #38444d;
}

li {
  float: left;
  border-right: 1px solid #bbb;
}

li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: #C36333;
}

li.dropdown {
  display: inline-block;
}
/*li:last-child {
  border-right: none;
}*/
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}
.flex-container{ 
    width: 100%; 
    height: 80vh; 
    display: -webkit-box; 
    display: -moz-box;
    display: -ms-flexbox; 
    display: flex; 

    -webkit-box-align: center; 
    -moz-box-align: center;
    -ms-flex-align: center;
    align-items: center; /* 수직 정렬 */

    -webkit-box-pack: center;
    -moz-box-pack: center; 
    -ms-flex-pack: center; 
    justify-content: center; /* 수평 정렬 */
}
#home{
  display: block;
  font-size: 70pt;
}


</style>

  <h1>NBA Reference</h1>



  <ul>
  <li><a href="home.php">Home</a></li>
  <li><a href="news.php">News</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2018-19</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="sr_18home.php">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals)(예정)</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2019-20</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="#">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals)(예정)</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2020-21</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="#">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals(예정))</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">2021-22</a>
    <div class="dropdown-content">
      <a href="#">Standings(예정)</a>
      <a href="#">Schedule & Result</a>
      <a href="#">Leaders(예정)</a>
      <a href="#">Stats(Per G & Totals)(예정)</a>
    </div>
  </li>
</ul>
<br>