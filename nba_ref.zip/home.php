<?php include("header.php");?>

<div id=home><div class=flex-container>Welcome! Here is NBA Reference!</div></div>


</body>