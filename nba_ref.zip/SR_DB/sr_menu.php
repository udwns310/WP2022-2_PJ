<style>
.myButton {
	box-shadow:inset 0px 1px 0px 0px #fce2c1;
	background:linear-gradient(to bottom, #ffc477 5%, #fb9e25 100%);
	background-color:#ffc477;
	border-radius:6px;
	border:1px solid #eeb44f;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	font-weight:bold;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #cc9f52;
    margin-left: 50px;
}
.myButton:hover {
	background:linear-gradient(to bottom, #fb9e25 5%, #ffc477 100%);
	background-color:#fb9e25;
}
.myButton:active {
	position:relative;
	top:1px;
}


</style>
<a href="sr_18_19_oct.php" class="myButton">10월</a>
<a href="sr_18_19_nov.php" class="myButton">11월</a>
<a href="#" class="myButton">12월</a>
<a href="#" class="myButton">1월</a>
<a href="#" class="myButton">2월</a>
<a href="#" class="myButton">3월</a>
<a href="#" class="myButton">4월</a>
<a href="#" class="myButton">5월</a>
<a href="#" class="myButton">6월</a>


